# Narcos Code Genel V4

(Ç)alana beleş telif ikram edilir
