const Discord = require('discord.js'); //DevTR | xFalcon
 //DevTR | xFalcon
 //DevTR | xFalcon
exports.run = function(client, message, args) {
 //DevTR | xFalcon
 //DevTR | xFalcon //DevTR | xFalcon //DevTR | xFalcon //DevTR | xFalcon
 //DevTR | xFalcon
 //DevTR | xFalcon //DevTR | xFalcon
 //DevTR | xFalcon
 //DevTR | xFalcon
message.channel.send(`Tablet Reyiz`, new Discord.Attachment("https://media1.tenor.com/images/c892c515cb488c9c14483b4deed6ca87/tenor.gif?itemid=14644456", "take-tabletreis.gif")) //DevTR | xFalcon
 //DevTR | xFalcon
 //DevTR | xFalcon
 //DevTR | xFalcon
}; //DevTR | xFalcon
exports.conf = {
  enabled: true,  //DevTR | xFalcon
  guildOnly: true,  //DevTR | xFalcon
  aliases: ["tablet"], //DevTR | xFalcon
  permLevel: 0  //DevTR | xFalcon
}; //DevTR | xFalcon
 //DevTR | xFalcon
 //DevTR | xFalcon
 //DevTR | xFalcon
exports.help = {
  name: 'tablet-reyiz',  //DevTR | xFalcon
  description: 'Belirtilen işlemi yapar.', //DevTR | xFalcon
  usage: 'tablet reyiz'  //DevTR | xFalcon
};